#include <cstdlib>

int main(void)
{
  if (1)
  {
    abort();
  }

  return 0;
}
