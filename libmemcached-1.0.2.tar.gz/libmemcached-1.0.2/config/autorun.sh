#!/bin/sh
autoreconf --install --force --verbose -Wall
